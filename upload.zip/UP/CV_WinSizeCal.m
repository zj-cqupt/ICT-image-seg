function [winS] = CV_WinSizeCal(R)
[h,w] = size(R);
%ROI
BW = im2bw(R,xu(0,R));
SE = strel('square',3);
BW2 = imdilate(BW,SE);
E = double(BW2).*double(R);
maxS = min(round(h/4),round(w/4));
winS = zeros(h,w);
[x y] = find(E~=0);
z = [x,y];
[h1,w1] = size(z);
%window size calculation
for i = 1:h1
    x = z(i,1);
    y = z(i,2);
    for winSize = 5:1:maxS
        curWin = E(x-winSize:x+winSize,y-winSize:y+winSize);
        
        inCount = (2*winSize+1)^2;
        inU = mean(curWin(:));
        inF = sum((curWin(:)-inU).^2);
        
        outCount = 3*h*3*w - inCount;
        outU = (sum(E(:))-sum(curWin(:)))/outCount;
        outWin = double(E);
        outWin(x-winSize:x+winSize,y-winSize:y+winSize) = outU;
        ouF = sum((outWin(:)-outU).^2);
        
        CG =  abs(inF/10^5-ouF/10^7);
        if winSize == 5
            PG = CG;
        end
        if CG>PG || (x-winSize)<=0 ||(y-winSize)<=0|| (x+winSize)>h||(y+winSize)>w
            winS(x,y) =  winSize;
            break;
        else PG = CG;
        end     
    end
end
end