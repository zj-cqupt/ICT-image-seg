function [ level2 ] = xu(kind,I)%kind=0,low;kind=1,high
    ranks = 256;
    level1 = graythresh(I);
    otsu = level1*256;
    level2 = otsu;
    counts = imhist(I,ranks);
    PixelPro = counts/sum(counts);
    sigma2 = -99999; 
    start1 =  1;
    endp=round(otsu);
    if kind == 0
       start1 =  1;
       endp = round(otsu);
    end
    if kind == 1
       start1 = round(otsu);
       endp = 256; 
    end
    p1 = 0;
    p0 = 0;
    u0 = 0;
    u1 = 0;
    u0temp = 0;
    u1temp = 0;
    u = 0;
    for i = start1:1:endp
        p1 = 0;
        p0 = 0;
        u0 = 0;
        u1 = 0;
        u0temp = 0;
        u1temp = 0;
        u = 0;
        for j = start1:1:endp
            if j <= i
               p0 = p0 +  PixelPro(j);
               u0temp = u0temp + j*PixelPro(j);
            end
            if j > i
                p1 = p1 + PixelPro(j);
                u1temp = u1temp + j*PixelPro(j);
            end
        end
        u0 = u0temp/p0;
        u1 = u1temp/p1; 
        u = u0temp+u1temp;
        sigma = (u0-u).^2*p0+(u1-u).^2*p1;%���
        if sigma > sigma2
           sigma2 = sigma;
           level2 = i;
          
        end
    end
    level2=level2/256;
end

