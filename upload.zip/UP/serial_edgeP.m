clear all
clc

start = 603;
endn = 614;
%combination result
Rpath =   'F:\MATLAB\SEG\';
Wpath =    'F:\MATLAB\SEG\';
SP = {};

for i=start:endn
    prefix = 'slice0';
    if length(num2str(round(i)))==4
    prefix = 'slice';
    end
    read = strcat(prefix,num2str(i),'-seg.bmp');  
    ORI =  imread([Rpath,read]);
    
    bw = edge(ORI);
    [x y] = find(bw==1);
    SP{i-start+1}=[x,y];
end
clearvars -except SP
%save 3D point cloud
save (Wpath,'SP' );
%export 3D point cloud to txt
pixelSize = 0.125518;
zp = pixelSize;
P = [];
sh = 0;
[hp,wp] = size(SP);
for i=1:wp
    cP = SP{i};
    [h,w]=size(cP);
    if i==1
        P(1:h,1:2)=cP;
        P(1:h,3)=1;
        sh = h;
    else
        P(sh+1:sh+h,1:2)=cP;
        P(sh+1:sh+h,3)=i;
        sh=sh+h;
    end
end
filename = strcat('F:\3DpointCloud\','edgeP.txt');
fp = fopen(filename,'wt');
[h w]=size(P);

for i = 1:h
    fprintf(fp, '%f ', P(i,1)*pixelSize);fprintf(fp, '%f ', P(i,2)*pixelSize);fprintf(fp,'%f\n',P(i,3)*zp);
end
 fclose(fp);