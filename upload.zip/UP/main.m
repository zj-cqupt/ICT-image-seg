clear all
clc
%local window size calculation
OriImage = 'slice0506_small';
OriStyle = '.bmp';
read = strcat(OriImage,OriStyle);
R = imread(read);
winS = CV_WinSizeCal(R);
clearvars -except winS
%img path
DBpath = 'E:\UP\';
File = dir(fullfile(DBpath,'*.BMP'));
FileNames = {File.name}';
Length_Names = size(FileNames,1);
for i=1:Length_Names
    curDir = strcat(DBpath,FileNames(i));
    im = imread(curDir{1});
%     [RESULT_XU, RESULT_SFCM, RESULT_DRLSE] = voting_part( im,winS);
[RESULT_XU, RESULT_SFCM, RESULT_DRLSE] = voting_part( im,winS);
%     save( strcat('test',num2str(i),'.mat'), 'RESULT_XU','RESULT_SFCM','RESULT_DRLSE');
end