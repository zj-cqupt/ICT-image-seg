1. run main.m first to get the voting results
2. run ParaOpt_STRARTER.m to optimize weights of each method. in this part, a marked image and corresponding original image are needed.
3. for multi-resolution images, run multiImgConv.m to get multi-resolution images. then go to setps 1 and 2 to get combination result. in the end run serial_edgeP to get 3D point cloud.