function [ VoteXu, VoteSFCM, VoteDRLSE] = voting_part( im,winS )
[h,w,N] = size(im);
if N ~= 0
    I(:,:) = im(:,:,1);
else
    I = im;
end
VoteXu = zeros(h,w);
VoteSFCM = zeros(h,w);
VoteDRLSE = zeros(h,w);
[x y] = find(winS~=0);
z = [x,y];
[h1,w1] = size(z);
for i=1:h1
    WinSize = round (winS(z(i,1),z(i,2)));
    [sWindow,locat] = sWindowCal(z,i,h,w,WinSize,I);
    type = 'xu';
    [VoteXu] = voteProcess (sWindow,VoteXu,locat,type);
    type = 'SFCM';
    [VoteSFCM] = voteProcess (sWindow,VoteSFCM,locat,type);
    
    type = 'DRLSE';
    [VoteDRLSE] = voteProcess (sWindow,VoteDRLSE,locat,type);
end
end
