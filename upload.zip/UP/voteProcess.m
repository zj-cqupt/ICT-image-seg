function [VoteMatrix] = voteProcess (sWindow,VoteMatrix,locat,type)
switch type
    case 'xu'
        level = 256*xu(0,sWindow);
    case 'SFCM'
        [MF,Cent,Obj] = SFCM2D(sWindow,2,50,2);
        temp1 = abs(double(sWindow)-min(Cent(:)));
        temp2 = abs(double(sWindow)-max(Cent(:)));
        sWindow = temp1-temp2;
        level = 0;
    case 'DRLSE'
        sWindow = -DRLSE(sWindow);
        level = 0;
end
sWindowPlus = double(sWindow>level);
VoteMatrix(locat(1,1):locat(1,2), locat(2,1):locat(2,2)) = VoteMatrix(locat(1,1):locat(1,2), locat(2,1):locat(2,2)) + sWindowPlus;
end


