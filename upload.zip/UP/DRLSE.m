function [u]=DRLSE(sWindow)
% This code demonstrates the level set evolution (LSE) and bias field estimation
% proposed in the following paper:
%      C. Li, R. Huang, Z. Ding, C. Gatenby, D. N. Metaxas, and J. C. Gore,
%      "A Level Set Method for Image Segmentation in the Presence of Intensity
%      Inhomogeneities with Application to MRI", IEEE Trans. Image Processing, 2011
%
Img=sWindow;
[h,w,N]=size(Img);
if N==1
    I=Img;
else
    I=Img(:,:,1);
end

Img=double(Img(:,:,1));
A=255;
Img=A*normalize01(Img); % rescale the image intensities
nu=0.001*A^2; % coefficient of arc length term
sigma = 40; % scale parameter that specifies the size of the neighborhood
iter_outer=50; 
iter_inner=10;   % inner iteration for level set evolution

timestep=.1;%0.1
mu=0.05;
c0=1;

% initialize level set function
initialLSF = c0*ones(size(Img));
initialLSF(10:h-10,10:w-10) = -c0;
u=initialLSF;%��ʼ����ʼ����Ϊ�м䳤����

epsilon=1;
b=ones(size(Img));  %%% initialize bias field

K=fspecial('gaussian',round(2*sigma)*2+1,sigma); 
KI=conv2(Img,K,'same');%
KONE=conv2(ones(size(Img)),K,'same');

[row,col]=size(Img);
N=row*col;

for n=1:iter_outer
    [u, b, C]= lse_bfe(u,Img, b, K,KONE, nu,timestep,mu,epsilon, iter_inner);
end
end

