function [result]=ParaOpt(X)
global RX;
global RS;
global RD;
global stdObj;
global stdBac;

%combined result
WX = X(1);
WS = X(2);
WD = X(3);
RALL = RX*WX + RS*WS + RD*WD;
fmin = min(RALL(:));
fmax = max(RALL(:));
RESULT = 255-255*(RALL-fmin)/(fmax-fmin);
RESULT(isnan(RESULT)) = 0;
%goal
curBW = im2bw(RESULT,graythresh(RESULT));
curBW = double(curBW);
curObj = double(RESULT).*curBW;
cutBac = double(RESULT).*abs(1-curBW);
stats = abs(std(curObj(:))-stdObj)+abs(std(cutBac(:))-stdBac);
result = -stats;
end






