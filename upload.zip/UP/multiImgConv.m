close all
clear all

startNo = 200;
endNo = 610;
postFix = '-seg.bmp';
Rpath = 'F:\MATLAB\ORI\';
Wpath = 'F:\MATLAB\Multi\';

for i = startNo : endNo
    prefix = 'slice0';
    if length(num2str(round(i)))==4
        prefix = 'slice';
    end
    
    imgName = strcat(prefix,num2str(i),postFix);
    sliceImg = imread([Rpath,imgName]);
    R = imresize(sliceImg, scaler, 'bicubic');
    imwrite(R,strcat(prefix,'m5.bmp'))
end


