clear all;
clc

global RX;
global RS;
global RD;
global stdObj;
global stdBac;

%read marked img and corresponding original image
stdImg = imread('slice0550_mark.bmp');%markded bw img
oriImg = imread('slice0550_small.bmp');%original image corresponds to marded image
if max(stdImg(:)) == 255
    stdImg = double(stdImg)./255;
else
    stdImg = double(stdImg);
end
markObj = double(oriImg) .*stdImg;
stdObj = std(markObj(:));
markBac = double(oriImg) .*abs(1-stdImg);
stdBac = std(markBac(:));

%img series
DBpath = 'E:\test\';%img path
File = dir(fullfile(DBpath,'*.bmp'));
FileNames = {File.name}';
Length_Names = size(FileNames,1);

for i=1:Length_Names
    data = strcat('test',num2str(i),'.mat');
    load data;
    %VOTING RESULT
    RX = double(RESULT_XU);
    RS = double(RESULT_SFCM);
    RD = -double(RESULT_DRLSE);
   
    %para opt
    A = [];b = [];
    Aeq = [1,1,1];Beq = 1;
    LB = [0,0,0];
    UB = [1,1,1];
    options = optimoptions('ga','Display','diagnose','MaxStallGenerations',10,'FunctionTolerance',1);
    [x,fval] = ga(@ParaOpt,3,A,b,Aeq,Beq,LB,UB,[],options);
    RESULT = x(1,1)*RX + x(1,2)*RS + x(1,3)*RD ;
    save( strcat('test',num2str(i),'OP.mat'), 'RESULT');
end