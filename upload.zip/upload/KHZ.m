function u=KHZ(Img)
Img = double(Img);
[row,col] = size(Img);
phi = ones(row,col);
phi(5:row-5,5:col-5) = -1;
u = - phi;
sigma = 1;
G = fspecial('gaussian', 5, sigma);
delt = 1;
% Iter = 50;
Iter = 30;
mu = 25;%this parameter needs to be tuned according to the images
for n = 1:Iter
    [ux, uy] = gradient(u);
   
    c1 = sum(sum(Img.*(u<0)))/(sum(sum(u<0)));% we use the standard Heaviside function which yields similar results to regularized one.
    c2 = sum(sum(Img.*(u>=0)))/(sum(sum(u>=0)));
    
    spf = Img - (c1 + c2)/2;
    spf = spf/(max(abs(spf(:))));
    
    u = u + delt*(mu*spf.*sqrt(ux.^2 + uy.^2));
    
    u = (u >= 0) - ( u< 0);% the selective step.
    u = conv2(u, G, 'same');
end
end


    

