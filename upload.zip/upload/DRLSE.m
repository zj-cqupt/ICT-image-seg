function [u]=DRLSE(sWindow)
[h,w]=size(sWindow);
A=255;
sWindow=A*normalize01(sWindow); % rescale the image intensities
nu=0.001*A^2; % coefficient of arc length term
sigma = 40; % scale parameter that specifies the size of the neighborhood
iter_outer=30;
iter_inner=20;   % inner iteration for level set evolution
timestep=.1;%0.1
mu=1;  % coefficient for distance regularization term (regularize the level set function)
c0=1;
% initialize level set function
initialLSF = c0*ones(size(sWindow));
initialLSF(10:h-10,10:w-10) = -c0;
u=initialLSF;
epsilon=1;
b=ones(size(sWindow));  %%% initialize bias field
K=fspecial('gaussian',round(2*sigma)*2+1,sigma);
KI=conv2(sWindow,K,'same');
KONE=conv2(ones(size(sWindow)),K,'same');
N=h*w;
for n=1:iter_outer
    [u, b, C]= lse_bfe(u,double(sWindow), b, K,KONE, nu,timestep,mu,epsilon, iter_inner);  
end
end

