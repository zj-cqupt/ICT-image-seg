function [  sWindow,locat] = sWindowCal(z,i,h,w,WinSize,I)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    locat(1,1) = z(i,1) -WinSize;
    locat(1,2)= z(i,1) + WinSize;
    locat(2,1) = z(i,2) -WinSize;
    locat(2,2)= z(i,2) +WinSize;
while locat(2,2)>w||locat(1,1)<=0||locat(1,2)>h||locat(2,1)<=0
    WinSize = WinSize-1;
    locat(1,1) = z(i,1) -WinSize;
    locat(1,2)= z(i,1) + WinSize;
    locat(2,1) = z(i,2) -WinSize;
    locat(2,2)= z(i,2) +WinSize;
end
sWindow = I(locat(1,1):locat(1,2) , locat(2,1):locat(2,2));
sWindow = uint8(sWindow);
end

