% function [ RESULT_XU, RESULT_SFCM, RESULT_KHZ] = voting_part( im,winS )
function [ RESULT_XU] = voting_part( im,winS )
[h,w,N] = size(im);
if N ~= 0
    I(:,:) = im(:,:,1);
else
    I = im;
end
VoteXu = zeros(h,w);
CountXu = zeros(h,w);
VoteSFCM = zeros(h,w);
CountSFCM = zeros(h,w);
VoteKHZ = zeros(h,w);
CountKHZ = zeros(h,w);

[x y] = find(winS~=0);
z = [x,y];
[h1,w1] = size(z);
for i=1:h1
    WinSize = round (winS(z(i,1),z(i,2))/2);
    [sWindow,locat] = sWindowCal(z,i,h,w,WinSize,I);
    type = 'xu';
    [VoteXu,CountXu] = voteProcess (sWindow,VoteXu,CountXu,locat,type);
    type = 'SFCM';
    [VoteSFCM,CountSFCM] = voteProcess (sWindow,VoteSFCM,CountSFCM,locat,type);
    type = 'KHZ';
    [VoteKHZ,CountKHZ] = voteProcess (sWindow,VoteKHZ,CountKHZ,locat,type);
    
end
RESULT_XU = VoteXu./CountXu;
RESULT_SFCM = VoteSFCM./CountSFCM;
RESULT_KHZ = VoteKHZ./CountKHZ;
end
